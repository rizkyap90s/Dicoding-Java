package com.example.submit2.model;

import android.os.Parcel;
import android.os.Parcelable;

public class TVshow implements Parcelable {

    private String title;
    private String poster;
    private String status;
    private String description;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.title);
        dest.writeString(this.poster);
        dest.writeString(this.status);
        dest.writeString(this.description);
    }

    public TVshow() {
    }

    protected TVshow(Parcel in) {
        this.title = in.readString();
        this.poster = in.readString();
        this.status = in.readString();
        this.description = in.readString();
    }

    public static final Parcelable.Creator<TVshow> CREATOR = new Parcelable.Creator<TVshow>() {
        @Override
        public TVshow createFromParcel(Parcel source) {
            return new TVshow(source);
        }

        @Override
        public TVshow[] newArray(int size) {
            return new TVshow[size];
        }
    };
}
