package com.example.submit2.adapter;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.submit2.detail.DetailMovie;
import com.example.submit2.R;
import com.example.submit2.model.Movie;

import java.util.ArrayList;

public class AdapterMovie extends RecyclerView.Adapter<AdapterMovie.MyHolder> {
    ArrayList<Movie> movie;
    Context context;

    public void setHeroes(ArrayList<Movie> movie) {
        this.movie = movie;
    }
    public AdapterMovie(Context context) {
        this.context = context;
        movie = new ArrayList<>();
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.custom_list_movie, viewGroup, false);
        return new MyHolder(v);
    }
    @Override
    public void onBindViewHolder(@NonNull final MyHolder holder, int i) {

        holder.txttitle.setText(movie.get(holder.getAdapterPosition()).getTitle());
        holder.txtrating.setText(movie.get(holder.getAdapterPosition()).getRating());
        holder.txtdesc.setText(movie.get(holder.getAdapterPosition()).getDescription());

        Glide.with(context)
                .load(movie.get(holder.getAdapterPosition()).getPoster())
                .apply(new RequestOptions().override(100,150))
                .into(holder.imgposter);

        holder.imgposter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img = new ImageView(context);
                Glide.with(context)
                        .load(movie.get(holder.getAdapterPosition()).getPoster())
                        .into(img);
                AlertDialog.Builder alert = new AlertDialog.Builder(context);
                alert
                        .setCustomTitle(img);
                Dialog dialog = alert.create();dialog.show();
            }
        });

        holder.clickdetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetailMovie.class);
                intent.putExtra("key", movie.get(holder.getAdapterPosition()));
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return movie.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {
        TextView txttitle, txtrating, txtdesc;
        CardView clickdetail;
        ImageView imgposter;
        public MyHolder(@NonNull View itemView) {
            super(itemView);
            clickdetail = itemView.findViewById(R.id.clickdetail);
            txttitle = itemView.findViewById(R.id.id_judulmovie);
            txtdesc = itemView.findViewById(R.id.id_descmovie);
            txtrating = itemView.findViewById(R.id.id_ratingmovie);
            imgposter = itemView.findViewById(R.id.id_postermovie);
        }
    }
}
