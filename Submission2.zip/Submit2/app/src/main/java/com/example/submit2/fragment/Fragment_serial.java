package com.example.submit2.fragment;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.submit2.R;
import com.example.submit2.adapter.AdapterTVshow;
import com.example.submit2.model.TVshow;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class Fragment_serial extends Fragment {
    RecyclerView recyclerView;
    ArrayList<TVshow> tVshows;
    private String[] data_tittle, data_poster, data_description, data_status;

    AdapterTVshow adapter;


    public Fragment_serial() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_fragment_tvshow, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        //init
        recyclerView = view.findViewById(R.id.rv_serial);
        adapter = new AdapterTVshow(getActivity());


        data_tittle = getResources().getStringArray(R.array.data_title_tv);
        data_poster = getResources().getStringArray(R.array.data_poster_tv);
        data_description = getResources().getStringArray(R.array.data_description_tv);
        data_status = getResources().getStringArray(R.array.data_rating_tv);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(adapter);
        datamovie();

        super.onViewCreated(view, savedInstanceState);
    }

    private void datamovie() {
        tVshows=new ArrayList<>();
        for (int i = 0; i < data_tittle.length; i++) {
            TVshow tv = new TVshow();
            tv.setTitle(data_tittle[i]);
            tv.setPoster(data_poster[i]);
            tv.setDescription(data_description[i]);
            tv.setStatus(data_status[i]);
            tVshows.add(tv);
        }
        adapter.settVshows(tVshows);
    }
}
