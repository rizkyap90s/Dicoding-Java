package com.example.submit2.detail;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.submit2.R;
import com.example.submit2.model.TVshow;

public class DetailTVshow extends AppCompatActivity {
    TextView txttitle, txtstatus, txtdescription;
    ImageView imgposter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_tvshow);

        init();

        TVshow tVshow = getIntent().getParcelableExtra("key");

        txttitle.setText(tVshow.getTitle());
        txtstatus.setText(tVshow.getStatus());
        txtdescription.setText(tVshow.getDescription());

        Glide.with(this)
                .load(tVshow.getPoster())
                .into(imgposter);

//        if (tVshow.getStatus() != "LIVE"){
//            txtstatus.setText("LIVE");
//            txtstatus.setTextColor(Color.GRAY);
//        }
//        else {
//            txtstatus.setText(tVshow.getStatus());
//        }

        if (getSupportActionBar() != null){
            getSupportActionBar().setTitle(tVshow.getTitle());
        }
    }

    private void init() {
        txttitle = findViewById(R.id.detail_titletv);
        txtstatus = findViewById(R.id.detail_statustv);
        txtdescription = findViewById(R.id.detail_desctv);
        imgposter = findViewById(R.id.detail_postertv);

    }

}
