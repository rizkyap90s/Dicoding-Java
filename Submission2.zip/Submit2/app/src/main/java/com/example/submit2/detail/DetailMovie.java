package com.example.submit2.detail;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.submit2.R;
import com.example.submit2.model.Movie;

public class DetailMovie extends AppCompatActivity {
    TextView txttitle, txtrating, txtdescription;
    ImageView imgposter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie);
        init();

        Movie movie = getIntent().getParcelableExtra("key");

        txttitle.setText(movie.getTitle());
        txtrating.setText(movie.getRating());
        txtdescription.setText(movie.getDescription());

        Glide.with(this)
                .load(movie.getPoster())
                .into(imgposter);

        if (getSupportActionBar() != null){
            getSupportActionBar().setTitle(movie.getTitle());
        }


    }

    private void init() {
        txttitle = findViewById(R.id.detail_titlemovie);
        txtrating = findViewById(R.id.detail_ratingmovie);
        txtdescription = findViewById(R.id.detail_descmovie);
        imgposter = findViewById(R.id.detail_postermovie);

    }
}
