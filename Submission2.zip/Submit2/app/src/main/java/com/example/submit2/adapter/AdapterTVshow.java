package com.example.submit2.adapter;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.submit2.R;
import com.example.submit2.detail.DetailTVshow;
import com.example.submit2.model.TVshow;

import java.util.ArrayList;

public class AdapterTVshow extends RecyclerView.Adapter<AdapterTVshow.MyHolder> {

    ArrayList<TVshow> tVshows;
    Context context;

    public void settVshows(ArrayList<TVshow> tVshows) {
        this.tVshows = tVshows;
    }
    public AdapterTVshow(Context context) {
        this.context = context;
        tVshows = new ArrayList<>();
    }
    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.custom_list_serial, viewGroup, false);
        return new MyHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyHolder holder, final int i) {

        holder.txtstatus.setText(tVshows.get(holder.getAdapterPosition()).getStatus());
        holder.txttitle.setText(tVshows.get(holder.getAdapterPosition()).getTitle());
        holder.txtdescription.setText(tVshows.get(holder.getAdapterPosition()).getDescription());

//        if (tVshows.get(i).getStatus()=="LIVE"){
//            holder.txtstatus.setText("LIVE");
//            holder.txtstatus.setTextColor(Color.RED);
//        }
//        else {
//            holder.txtstatus.setText("LIVE");
//            holder.txtstatus.setTextColor(Color.GRAY);
//        }

        Glide.with(context)
                .load(tVshows.get(holder.getAdapterPosition()).getPoster())
                .apply(new RequestOptions().override(100,150))
                .into(holder.imgposter);

        holder.imgposter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img = new ImageView(context);
                Glide.with(context)
                        .load(tVshows.get(holder.getAdapterPosition()).getPoster())
                        .into(img);
                AlertDialog.Builder alert = new AlertDialog.Builder(context);
                alert
                        .setCustomTitle(img);
                Dialog dialog = alert.create();dialog.show();
            }
        });

        holder.clickdetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetailTVshow.class);
                intent.putExtra("key", tVshows.get(holder.getAdapterPosition()));
                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return tVshows.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {
        TextView txttitle, txtdescription, txtstatus;
        ImageView imgposter;
        CardView clickdetail;
        public MyHolder(@NonNull View itemView) {
            super(itemView);
            txttitle = itemView.findViewById(R.id.id_judultv);
            txtdescription = itemView.findViewById(R.id.id_desctv);
            txtstatus = itemView.findViewById(R.id.id_statustv);
            imgposter = itemView.findViewById(R.id.id_postertv);
            clickdetail = itemView.findViewById(R.id.clickdetail);


        }
    }
}
