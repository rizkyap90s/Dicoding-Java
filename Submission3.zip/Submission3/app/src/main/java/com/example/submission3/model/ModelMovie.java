package com.example.submission3.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class ModelMovie implements Parcelable {

    @SerializedName("original_title")
    private String movie_title;

    @SerializedName("vote_average")
    private Double movie_rating;

    @SerializedName("poster_path")
    private String movie_poster;

    @SerializedName("backdrop_path")
    private String movie_backdrop;

    @SerializedName("overview")
    private String movie_overview;

    @SerializedName("release_date")
    private String movie_date;


    public ModelMovie(String movie_title, Double movie_rating, String movie_poster, String movie_backdrop, String movie_overview, String movie_date) {
        this.movie_title = movie_title;
        this.movie_rating = movie_rating;
        this.movie_poster = movie_poster;
        this.movie_backdrop = movie_backdrop;
        this.movie_overview = movie_overview;
        this.movie_date = movie_date;
    }

    public String getMovie_title() {
        return movie_title;
    }

    public void setMovie_title(String movie_title) {
        this.movie_title = movie_title;
    }

    public Double getMovie_rating() {
        return movie_rating;
    }

    public void setMovie_rating(Double movie_rating) {
        this.movie_rating = movie_rating;
    }

    public String getMovie_poster() {
        return "https://image.tmdb.org/t/p/w500"+ movie_poster;
    }

    public void setMovie_poster(String movie_poster) {
        this.movie_poster = movie_poster;
    }

    public String getMovie_backdrop() {
        return "https://image.tmdb.org/t/p/w500"+ movie_backdrop;
    }

    public void setMovie_backdrop(String movie_backdrop) {
        this.movie_backdrop = movie_backdrop;
    }

    public String getMovie_overview() {
        return movie_overview;
    }

    public void setMovie_overview(String movie_overview) {
        this.movie_overview = movie_overview;
    }

    public String getMovie_date() {
        return movie_date;
    }

    public void setMovie_date(String movie_date) {
        this.movie_date = movie_date;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.movie_title);
        dest.writeValue(this.movie_rating);
        dest.writeString(this.movie_poster);
        dest.writeString(this.movie_backdrop);
        dest.writeString(this.movie_overview);
        dest.writeString(this.movie_date);
    }

    protected ModelMovie(Parcel in) {
        this.movie_title = in.readString();
        this.movie_rating = (Double) in.readValue(Double.class.getClassLoader());
        this.movie_poster = in.readString();
        this.movie_backdrop = in.readString();
        this.movie_overview = in.readString();
        this.movie_date = in.readString();
    }

    public static final Parcelable.Creator<ModelMovie> CREATOR = new Parcelable.Creator<ModelMovie>() {
        @Override
        public ModelMovie createFromParcel(Parcel source) {
            return new ModelMovie(source);
        }

        @Override
        public ModelMovie[] newArray(int size) {
            return new ModelMovie[size];
        }
    };
}
