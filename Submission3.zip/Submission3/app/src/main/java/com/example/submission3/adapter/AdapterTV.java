package com.example.submission3.adapter;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.submission3.R;
import com.example.submission3.detail.DetailMovie;
import com.example.submission3.detail.DetailTV;
import com.example.submission3.model.ModelMovie;
import com.example.submission3.model.ModelTV;

import java.util.ArrayList;
import java.util.List;

public class AdapterTV extends RecyclerView.Adapter<AdapterTV.Holder> {

    Context context;
    List<ModelTV> modelTVS;

    public AdapterTV(Context context, List<ModelTV> modelTVS) {
        this.context=context;
        this.modelTVS=modelTVS;
    }
    public List<ModelTV> getTV(){
        return modelTVS;
    }
    public void setTV(List<ModelTV> modelTVS){
        this.modelTVS=modelTVS;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(context).inflate(R.layout.custom_list_tv, viewGroup, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final Holder holder, int i) {

        holder.txttitletv.setText(modelTVS.get(holder.getAdapterPosition()).getTv_title());
        holder.txtoverviewtv.setText(modelTVS.get(holder.getAdapterPosition()).getTv_overview());
        String rate = Double.toString(modelTVS.get(holder.getAdapterPosition()).getTv_rating());
        holder.txtratingtv.setText(rate);
        Glide.with(context)
                .load(modelTVS.get(holder.getAdapterPosition()).getTv_poster())
                .into(holder.imgpostertv);

        holder.imgpostertv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView imgshow = new ImageView(context);
                Glide.with(context)
                        .load(modelTVS.get(holder.getAdapterPosition()).getTv_poster())
                        .into(imgshow);
                AlertDialog.Builder showpicture = new AlertDialog.Builder(context);
                showpicture.setCustomTitle(imgshow);
                Dialog dialog = showpicture.create(); dialog.show();
            }
        });

        holder.clickdetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetailTV.class);
                intent.putExtra("key", modelTVS.get(holder.getAdapterPosition()));
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return modelTVS.size();
    }

    public class Holder extends RecyclerView.ViewHolder {
        ImageView imgpostertv;
        TextView txttitletv, txtoverviewtv,txtratingtv;
        CardView clickdetail;
        public Holder(@NonNull View item) {
            super(item);
            imgpostertv = item.findViewById(R.id.id_postertv);
            txttitletv = item.findViewById(R.id.id_judultv);
            txtratingtv = item.findViewById(R.id.id_ratingtv);
            txtoverviewtv = item.findViewById(R.id.id_desctv);
            clickdetail = item.findViewById(R.id.clickdetail);
        }
    }
}
