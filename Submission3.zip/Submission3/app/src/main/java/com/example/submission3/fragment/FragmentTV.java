package com.example.submission3.fragment;


import android.app.ProgressDialog;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.submission3.BuildConfig;
import com.example.submission3.R;
import com.example.submission3.adapter.AdapterMovie;
import com.example.submission3.adapter.AdapterTV;
import com.example.submission3.api.MovieClient;
import com.example.submission3.api.MovieService;
import com.example.submission3.api.TvClient;
import com.example.submission3.api.TvService;
import com.example.submission3.model.ModelMovie;
import com.example.submission3.model.ModelTV;
import com.example.submission3.model.MovieRespone;
import com.example.submission3.model.TvRespone;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentTV extends Fragment {
    SwipeRefreshLayout swipeRefreshLayout;
    RecyclerView recyclerView;
    ProgressDialog progressDialog;
    List<ModelTV> modelTVS;
    AdapterTV adapterTV;



    public FragmentTV() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_fragment_tv, container, false);
    }
    @Override
    public void onViewCreated(@NonNull final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        swipeRefreshLayout = view.findViewById(R.id.main_view2);
        recyclerView = view.findViewById(R.id.rv_tv);

        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Loading Data");
        progressDialog.setCancelable(false);
        progressDialog.show();

        if(getActivity().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT || getActivity().getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){
            recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        }
        modelTVS = new ArrayList<>();
        adapterTV = new AdapterTV(getActivity(), modelTVS);
        recyclerView.setAdapter(adapterTV);

        loadJsoon();

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefreshLayout = view.findViewById(R.id.main_view);
                recyclerView = view.findViewById(R.id.rv_movie);

                progressDialog = new ProgressDialog(getActivity());
                progressDialog.setMessage("Loading Data");
                progressDialog.setCancelable(false);
                progressDialog.show();

                if(getActivity().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT || getActivity().getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){
                    recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                }
                modelTVS = new ArrayList<>();
                adapterTV = new AdapterTV(getActivity(), modelTVS);
                recyclerView.setAdapter(adapterTV);

                loadJsoon();
            }
        });

    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        modelTVS = new ArrayList<>();
        outState.putParcelableArrayList("tv", new ArrayList<>(adapterTV.getTV()));
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (savedInstanceState != null){
            ArrayList<ModelTV> mTv;
            mTv = savedInstanceState.getParcelableArrayList("tv");
            adapterTV.setTV(mTv);
            recyclerView.setAdapter(adapterTV);
            progressDialog.dismiss();

        }
    }

    private void loadJsoon() {

        try {
            TvClient client = new TvClient();
            final TvService service = client.getTvClient().create(TvService.class);

            Call<TvRespone> call = service.getOnTheAirTv(BuildConfig.API_KEY);
            call.enqueue(new Callback<TvRespone>() {
                @Override
                public void onResponse(Call<TvRespone> call, Response<TvRespone> response) {
                    List<ModelTV> modelTVS = response.body().getTvResult();
                    recyclerView.setAdapter(new AdapterTV(getActivity(), modelTVS));
                    adapterTV.setTV(modelTVS);
                    if (swipeRefreshLayout.isRefreshing()){
                        swipeRefreshLayout.setRefreshing(false);
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<TvRespone> call, Throwable t) {
                    Toast.makeText(getActivity(), t.toString(), Toast.LENGTH_SHORT).show();

                }
            });

        }
        catch (Exception e){
            Toast.makeText(getActivity(), "Error", Toast.LENGTH_SHORT).show();
        }



    }

}
