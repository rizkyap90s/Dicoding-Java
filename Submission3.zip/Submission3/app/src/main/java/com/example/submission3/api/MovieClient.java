package com.example.submission3.api;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MovieClient {
    private static final String base_url = "https://api.themoviedb.org/3/";
    public static Retrofit retrofit = null;

    public static Retrofit getMovieClient(){
        if (retrofit ==null){
            retrofit = new Retrofit.Builder()
                    .baseUrl(base_url)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }

}
