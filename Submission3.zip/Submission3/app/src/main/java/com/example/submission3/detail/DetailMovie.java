package com.example.submission3.detail;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.submission3.R;
import com.example.submission3.model.ModelMovie;

public class DetailMovie extends AppCompatActivity {
    TextView txttitle, txtrating, txtdescription;
    ImageView imgposter, imgbackdrop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie);

        init();

        ModelMovie movie = getIntent().getParcelableExtra("key");

        txttitle.setText(movie.getMovie_title());
        String rate = Double.toString(movie.getMovie_rating());
        txtrating.setText(rate);
        txtdescription.setText(movie.getMovie_overview());

        Glide.with(this)
                .load(movie.getMovie_poster())
                .into(imgposter);

        Glide.with(this)
                .load(movie.getMovie_backdrop())
                .into(imgbackdrop);

        if (getSupportActionBar() != null){
            getSupportActionBar().setTitle(movie.getMovie_title());
        }

    }

    private void init() {
        txttitle = findViewById(R.id.detail_titlemovie);
        txtrating = findViewById(R.id.detail_ratingmovie);
        txtdescription = findViewById(R.id.detail_descmovie);
        imgposter = findViewById(R.id.detail_postermovie);
        imgbackdrop = findViewById(R.id.detail_backdropmovie);

    }
}
