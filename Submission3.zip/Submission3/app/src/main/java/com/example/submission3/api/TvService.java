package com.example.submission3.api;

import com.example.submission3.model.MovieRespone;
import com.example.submission3.model.TvRespone;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface TvService {

    @GET("tv/on_the_air")
    Call<TvRespone> getOnTheAirTv(@Query("api_key")String apikey);

}
