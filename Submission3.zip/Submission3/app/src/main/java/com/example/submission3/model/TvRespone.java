package com.example.submission3.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TvRespone {
    @SerializedName("results")
    private List<ModelTV> tv_result;

    public List<ModelTV> getTvResult(){
        return tv_result;
    }
    public void setMovieResult(List<ModelTV> tv_result){
        this.tv_result=tv_result;
    }
}
