package com.example.submission3.detail;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.submission3.R;
import com.example.submission3.model.ModelMovie;
import com.example.submission3.model.ModelTV;

public class DetailTV extends AppCompatActivity {
    TextView txttitle, txtrating, txtdescription;
    ImageView imgposter, imgbacdrop;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_tv);
        init();

        ModelTV tv = getIntent().getParcelableExtra("key");

        txttitle.setText(tv.getTv_title());
        String rate = Double.toString(tv.getTv_rating());
        txtrating.setText(rate);
        txtdescription.setText(tv.getTv_overview());

        Glide.with(this)
                .load(tv.getTv_poster())
                .into(imgposter);

        Glide.with(this)
                .load(tv.getTv_backdrop())
                .into(imgbacdrop);


        if (getSupportActionBar() != null){
            getSupportActionBar().setTitle(tv.getTv_title());
        }
    }

    private void init() {
        txttitle = findViewById(R.id.detail_titletv);
        txtrating = findViewById(R.id.detail_ratingtv);
        txtdescription = findViewById(R.id.detail_desctv);
        imgposter = findViewById(R.id.detail_postertv);
        imgbacdrop = findViewById(R.id.detail_backdroptv);
    }
}
