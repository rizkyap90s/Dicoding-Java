package com.example.submission3.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class ModelTV implements Parcelable {
    @SerializedName("original_name")
    private String tv_title;

    @SerializedName("vote_average")
    private Double tv_rating;

    @SerializedName("poster_path")
    private String tv_poster;

    @SerializedName("backdrop_path")
    private String tv_backdrop;

    @SerializedName("overview")
    private String tv_overview;

    @SerializedName("first_air_date")
    private String tv_date;

    public ModelTV(String tv_title, Double tv_rating, String tv_poster, String tv_backdrop, String tv_overview, String tv_date) {
        this.tv_title = tv_title;
        this.tv_rating = tv_rating;
        this.tv_poster = tv_poster;
        this.tv_backdrop = tv_backdrop;
        this.tv_overview = tv_overview;
        this.tv_date = tv_date;
    }

    public String getTv_title() {
        return tv_title;
    }

    public void setTv_title(String tv_title) {
        this.tv_title = tv_title;
    }

    public Double getTv_rating() {
        return tv_rating;
    }

    public void setTv_rating(Double tv_rating) {
        this.tv_rating = tv_rating;
    }

    public String getTv_poster() {
        return "https://image.tmdb.org/t/p/w500" + tv_poster;
    }

    public void setTv_poster(String tv_poster) {
        this.tv_poster = tv_poster;
    }

    public String getTv_backdrop() {
        return "https://image.tmdb.org/t/p/w500" + tv_backdrop;
    }

    public void setTv_backdrop(String tv_backdrop) {
        this.tv_backdrop = tv_backdrop;
    }

    public String getTv_overview() {
        return tv_overview;
    }

    public void setTv_overview(String tv_overview) {
        this.tv_overview = tv_overview;
    }

    public String getTv_date() {
        return tv_date;
    }

    public void setTv_date(String tv_date) {
        this.tv_date = tv_date;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.tv_title);
        dest.writeValue(this.tv_rating);
        dest.writeString(this.tv_poster);
        dest.writeString(this.tv_backdrop);
        dest.writeString(this.tv_overview);
        dest.writeString(this.tv_date);
    }

    protected ModelTV(Parcel in) {
        this.tv_title = in.readString();
        this.tv_rating = (Double) in.readValue(Double.class.getClassLoader());
        this.tv_poster = in.readString();
        this.tv_backdrop = in.readString();
        this.tv_overview = in.readString();
        this.tv_date = in.readString();
    }

    public static final Parcelable.Creator<ModelTV> CREATOR = new Parcelable.Creator<ModelTV>() {
        @Override
        public ModelTV createFromParcel(Parcel source) {
            return new ModelTV(source);
        }

        @Override
        public ModelTV[] newArray(int size) {
            return new ModelTV[size];
        }
    };
}
