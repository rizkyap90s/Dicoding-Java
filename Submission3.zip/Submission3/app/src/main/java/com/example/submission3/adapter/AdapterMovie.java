package com.example.submission3.adapter;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.submission3.R;
import com.example.submission3.detail.DetailMovie;
import com.example.submission3.model.ModelMovie;

import java.util.ArrayList;
import java.util.List;

public class AdapterMovie extends RecyclerView.Adapter<AdapterMovie.Holder> {

    Context context;
    List<ModelMovie> modelMovies;

    public AdapterMovie(Context context, List<ModelMovie> modelMovies) {
        this.context=context;
        this.modelMovies=modelMovies;
    }
    public List<ModelMovie> getMovie(){
        return modelMovies;
    }
    public void setMovies(List<ModelMovie> modelMovies){
        this.modelMovies=modelMovies;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(context).inflate(R.layout.custom_list_movie, viewGroup, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final Holder holder, int i) {
        holder.txttitlemovie.setText(modelMovies.get(holder.getAdapterPosition()).getMovie_title());
        holder.txtoverviewmovie.setText(modelMovies.get(holder.getAdapterPosition()).getMovie_overview());
        String rate = Double.toString(modelMovies.get(holder.getAdapterPosition()).getMovie_rating());
        holder.txtratingmovie.setText(rate);
        Glide.with(context)
                .load(modelMovies.get(holder.getAdapterPosition()).getMovie_poster())
                .into(holder.imgpostermovie);

        holder.imgpostermovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView imgshow = new ImageView(context);
                Glide.with(context)
                        .load(modelMovies.get(holder.getAdapterPosition()).getMovie_poster())
                        .into(imgshow);
                AlertDialog.Builder showpicture = new AlertDialog.Builder(context);
                showpicture.setCustomTitle(imgshow);
                Dialog dialog = showpicture.create(); dialog.show();
            }
        });

        holder.clickdetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetailMovie.class);
                intent.putExtra("key", modelMovies.get(holder.getAdapterPosition()));
                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return modelMovies.size();
    }

    public class Holder extends RecyclerView.ViewHolder {
        ImageView imgpostermovie;
        TextView txttitlemovie, txtoverviewmovie,txtratingmovie;
        CardView clickdetail;
        public Holder(@NonNull View item) {
            super(item);
            imgpostermovie = item.findViewById(R.id.id_postermovie);
            txttitlemovie = item.findViewById(R.id.id_judulmovie);
            txtratingmovie = item.findViewById(R.id.id_ratingmovie);
            txtoverviewmovie = item.findViewById(R.id.id_descmovie);
            clickdetail = item.findViewById(R.id.clickdetail);

        }
    }
}
