package com.example.submission3.api;

import com.example.submission3.model.MovieRespone;

import java.util.Calendar;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface MovieService {

    @GET("movie/now_playing")
    Call<MovieRespone> getNowPlayingMovie(@Query("api_key")String apikey);

}
