package com.example.listmovie;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;



public class DetailMovie extends AppCompatActivity {
    TextView txtjudul, txtrating, txtdeskripsi;
    ImageView imgposter;

    public static final String EXTRA_PERSON = "extra_person";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie);
        init();

        Movie movie = getIntent().getParcelableExtra(EXTRA_PERSON);

        txtjudul.setText(movie.getJudul());
        txtrating.setText(movie.getRating());
        txtdeskripsi.setText(movie.getDeskripsi());
        Glide.with(this)
                .load(movie.getPoster())
                .into(imgposter);


        if(getSupportActionBar()!= null){
            getSupportActionBar().setTitle(movie.getJudul());
        }

    }

    private void init() {
        txtjudul = findViewById(R.id.detail_judul);
        txtdeskripsi  = findViewById(R.id.detail_deskripsi);
        txtrating = findViewById(R.id.detail_rating);
        imgposter = findViewById(R.id.detail_poster);
    }
}
