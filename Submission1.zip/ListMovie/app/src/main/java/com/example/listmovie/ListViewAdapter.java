package com.example.listmovie;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class ListViewAdapter extends BaseAdapter {
    Context context;
    ArrayList <Movie> movie;

    public ListViewAdapter(Context context, ArrayList<Movie> movie) {
//        super(context,R.layout.custom_listview,movie);
        this.movie=movie;
        this.context=context;
    }

    @Override
    public int getCount() {
        return movie.size();
    }

    @Override
    public Movie getItem(int position) {
        return movie.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View view, ViewGroup parent) {
        view = LayoutInflater.from(context).inflate(R.layout.custom_listview, parent, false);
        TextView txtjudul;
        LinearLayout klik;
        ImageView imgposter;

        klik = view.findViewById(R.id.parent);
        imgposter = view.findViewById(R.id.id_poster);
        txtjudul = view.findViewById(R.id.id_judul);

        Glide.with(context)
                .load(movie.get(position).getPoster())
                .into(imgposter);

        txtjudul.setText(movie.get(position).getJudul());

        klik.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetailMovie.class);
                intent.putExtra(DetailMovie.EXTRA_PERSON, movie.get(position));
                context.startActivity(intent);

            }
        });

        return view;
    }
}
