package com.example.finalproject.respone;

import com.example.finalproject.model.Movie;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class MovieRespone {
    @SerializedName("results")
    private List<Movie> movie_result;

    public List<Movie> getMovieResult(){
        return movie_result;
    }
    public void setMovieResult(List<Movie> movie_result){
        this.movie_result=movie_result;
    }
}
