package com.example.finalproject.api;

import com.example.finalproject.respone.TvRespone;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface TvService {
    @GET("tv/airing_today")
    Call<TvRespone> getTvAiringToday(@Query("api_key") String apikey);

}
