package com.example.finalproject.detail;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.finalproject.R;
import com.example.finalproject.db.MovieHelper;
import com.example.finalproject.db.TvHelper;
import com.example.finalproject.model.Favorite;
import com.example.finalproject.model.Movie;
import com.example.finalproject.model.TV;

public class Favorite_detail extends AppCompatActivity {

    public static String FAV ="fav";

    TextView txttitle, txtoverview, txtrate, txtlanguage;
    ImageView imgbackdrop, imgposter;
    ImageButton btnstatus;

    MovieHelper movieHelper;
    TvHelper tvHelper;

    String id, title,overview,language,poster,backdrop,status;
    double rate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite_detail);
        txttitle = findViewById(R.id.detail_title_fav);
        txtoverview = findViewById(R.id.detail_desc_fav);
        txtrate = findViewById(R.id.detail_rating_fav);
        txtlanguage = findViewById(R.id.detail_language_fav);
        imgbackdrop = findViewById(R.id.detail_backdrop_fav);
        imgposter = findViewById(R.id.detail_poster_fav);
        btnstatus = findViewById(R.id.detail_status_fav);

        final Favorite favorite = getIntent().getExtras().getParcelable(FAV);
        txttitle.setText(favorite.getFav_title());
        txtoverview.setText(favorite.getFav_overview());
        String rate = Double.toString(favorite.getFav_rating());
        txtrate.setText(rate);
        txtlanguage.setText(favorite.getFav_language());
        Glide.with(this)
                .load(favorite.getFav_poster())
                .into(imgposter);
        Glide.with(this)
                .load(favorite.getFav_backdrop())
                .into(imgbackdrop);

        final MovieHelper movieHelper = new MovieHelper(this);
        movieHelper.open();
        final TvHelper tvHelper = new TvHelper(this);
        tvHelper.open();

        if (favorite.getFav_id() != null){
            btnstatus.setImageDrawable(getResources().getDrawable(R.drawable.liked));
        }
        btnstatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnstatus.setImageDrawable(getResources().getDrawable(R.drawable.dislike));
                movieHelper.delete(favorite.getFav_id());
                tvHelper.delete(favorite.getFav_id());

            }
        });

    }
}
