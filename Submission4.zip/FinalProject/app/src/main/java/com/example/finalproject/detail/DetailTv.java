package com.example.finalproject.detail;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.finalproject.R;
import com.example.finalproject.db.MovieHelper;
import com.example.finalproject.db.TvHelper;
import com.example.finalproject.model.Favorite;
import com.example.finalproject.model.TV;

public class DetailTv extends AppCompatActivity {

    public static final String KEY_TV="tv";

    TextView txttitle, txtoverview, txtrate, txtlanguage;
    ImageView imgbackdrop, imgposter;
    ImageButton btnstatus;

    private TvHelper tvHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_tv);

        txttitle = findViewById(R.id.detail_title_tv);
        txtoverview = findViewById(R.id.detail_desc_tv);
        txtrate = findViewById(R.id.detail_rating_tv);
        txtlanguage  = findViewById(R.id.detail_language_tv);
        btnstatus = findViewById(R.id.detail_status_tv);
        imgposter = findViewById(R.id.detail_poster_tv);
        imgbackdrop = findViewById(R.id.detail_backdrop_tv);

        final TV tv = getIntent().getExtras().getParcelable(KEY_TV);
        txttitle.setText(tv.getTv_title());
        txtoverview.setText(tv.getTv_overview());
        String rate = Double.toString(tv.getTv_rate());
        txtrate.setText(rate);
        txtlanguage.setText(tv.getTv_language());
        Glide.with(this)
                .load(tv.getTv_poster())
                .into(imgposter);
        Glide.with(this)
                .load(tv.getTv_backdrop())
                .into(imgbackdrop);

        tvHelper = new TvHelper(this);
        tvHelper.open();

        if (!tvHelper.hasObject(tv.getTv_id())) {
            btnstatus.setImageDrawable(getResources().getDrawable(R.drawable.liked));
        }

        btnstatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!tvHelper.hasObject(tv.getTv_id())){
                    remove();
                    btnstatus.setImageDrawable(getResources().getDrawable(R.drawable.dislike));
                }
                else{
                    add();
                    btnstatus.setImageDrawable(getResources().getDrawable(R.drawable.liked));
                }
            }
        });


    }

    private void add() {
        TV tv = getIntent().getExtras().getParcelable(KEY_TV);

        Favorite favorite = new Favorite();
        favorite.setFav_id(tv.getTv_id());
        favorite.setFav_title(tv.getTv_title());
        favorite.setFav_overview(tv.getTv_overview());
        favorite.setFav_rating(tv.getTv_rate());
        favorite.setFav_language(tv.getTv_language());
        favorite.setFav_poster(tv.getTv_poster());
        favorite.setFav_backdrop(tv.getTv_backdrop());
        tvHelper.insert(favorite);
    }

    private void remove() {
        TV tv = getIntent().getExtras().getParcelable(KEY_TV);

        tvHelper.delete(tv.getTv_id());
    }
}
